<?php

	if (basename($_SERVER["PHP_SELF"]) != "index.php")
	{
		header("Location:../index.php?view=accueil");
		die("");
	}

?>			
	<div id="projet">
		</br>
		</br>

		<div id="texte">
			<div id="contenu">
			</br>
			<h1 class="cover-heading">LPC Tour</h1>
			</br>
			<p>
				
				Cet outil conçu par le Pays d’art et d’histoire de la Communauté d’Agglomération de Lens-Liévin vous permet de découvrir les principaux édifices du centre-ville et en donne quelques clés. 
				Etudiantes de licence professionnelle dans le domaine du tourisme à l’IUT de Lens nous avons décidé de vous rendre cette visite plus interactive grâce à la création d’une web app vous permettant de localiser les différents monuments et avoir une explication de ces lieux. 
				</br>
				</br>
				Occupée d’octobre 1914 à octobre 1918, victime des bombardements et du sabotage méthodique opéré par les Allemands lors de leur retraite, Lens est détruite à 90% à l’issue de la Première Guerre mondiale. L’entreprise de reconstruction qui s’étale jusqu’à la fin des années 1920 est considérable. Comme l’exige la loi Cornudet de 1919, la ville se dote d’un Plan d’Alignement, d’Embellissement et d’Extension approuvé en 1924. Toutefois, aucune règle spécifique n’est prescrite en matière d’architecture. 
				</br>
				</br>
				Dès lors, propriétaires et architectes profitent d’une totale liberté : reconstruite à l’identique, recourir à des styles connus avant la guerre - néoclassique ou régionaliste par exemple – ou, au contraire, faire le choix de la modernité par l’emploi d’un style alors en plein essor à cette période, l’Art déco. 
				</br>
				</br>
				L’Exposition Internationale des Arts Décoratifs et Industriels Modernes de Paris en 1925 est déterminante dans la diffusion de ce courant. Avec ses formes géométriques et ses motifs floraux stylisés, l’Art déco se répand largement durant l’entre-deux-guerres à la faveur de la Reconstruction des villes et des villages meurtris par les combats de 1914 – 1918. L’art déco à Lens est généralement mêlé à d’autres influences, mais se révèle d’une richesse insoupçonnée pour un œil averti.
				</div>
				</br>
			</p>

		</div>
			
	</div>
