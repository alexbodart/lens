<?php

	if (basename($_SERVER["PHP_SELF"]) != "index.php")
	{
		header("Location:../index.php?view=accueil");
		die("");
	}
?>

	<div id="lieux">
		<div id="texte">
		<div id="contenu">
			<form method='POST' action="#">
				<h3>Les monuments</h3>
				<h4>Choisissez un monument</h4>
				<div class="liste-choix">
			    <span class="custom-dropdown custom-dropdown--white">
			        <select name="users" class="custom-dropdown__select custom-dropdown__select--white" onchange="showUser(this.value)">
			        	<option value="">Choix du monument</option>
			            <option value="1">La Gare SNCF</option>
			            <option value="2">Rue de la gare</option>
			            <option value="3">Rue du Havre</option>
			            <option value="4">La place Jean-Jaurès</option>
			            <option value="5">L’église Saint Léger</option>
			            <option value="6">L’Hôtel des Postes</option>
			            <option value="7">Le monument aux morts de la Première Guerre Mondiale</option>
			            <option value="8">Rue Lannoy</option>
			            <option value="9">La Maison Syndicale des mineurs</option>
			            <option value="15">La faculté des sciences Jean Perrin</option>
			            <option value="20">Le Stade Bollaert-Delelis</option>
			            <option value="21">Le Louvre-Lens</option>
						<optgroup label="Boulevard Emile Basly">
			            <option value="10">N°2</option>
			            <option value="11">Le collège Michelet</option>
			            <option value="12">N°98</option>
			            <option value="13">N°83</option>
			            <option value="14">N°124</option>
			            </optgroup>
						<optgroup label="Maisons des dirigeants et ingénieurs de la Société des Mines de Lens">
			            <option value="16">N°1 Avenue Elie Reumaux</option>
			            <option value="17">N°27 et 29 rue du Wetz</option>
			            <option value="18">N°34-36 rue du 11 novembre </option>
			            <option value="19">N°20 rue Jean Souvraz</option>
			            </optgroup>
			        </select>
			    </span>
			</div>
			</form>
		</br>
			<div id="txtHint"><b>Choisissez un monument dans la liste et découvrez son histoire ...</b></div>
		</div>
	</div>
</div>