<?php

	include("./libs/modele.php");

	// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
	if (basename($_SERVER["PHP_SELF"]) != "index.php")
	{
		header("Location:../index.php");
		die("");
	}

	// Pose qq soucis avec certains serveurs...
	echo "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

?>

<!DOCTYPE html>
<html lang="fr">
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Lens</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

		<!-- Bootstrap JS -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<!-- Personnal CSS -->
		<link rel="stylesheet" type="text/css" href="./css/default.css">
		<link rel="stylesheet" type="text/css" href="./css/lieux.css">
		<link rel="stylesheet" type="text/css" href="./css/logSign.css">

		
			<!-- Personnal JS -->
<script>
function showUser(str) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "./templates/getuser.php?q=" + str, true);
        xmlhttp.send();
}
$(document).ready(function() {
 
    $('#sncf').hide(); // on cache le champ par défaut
    $('#send').hide();
     
    $('select[name="jeu"]').change(function() { // lorsqu'on change de valeur dans la liste
    var valeur = $(this).val(); // valeur sélectionnée
     
        if(valeur != '') { // si non vide
            if(valeur == '1') { // si "sncf"
                $('#sncf').show();
            } else {
                $('#sncf').hide();           
            }
            $('#send').show();
        }
    });
 
});
</script>
	</head>

	<body>

		<div id="wrap">
  
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<a class="navbar-brand" href="#">
						<p><span class="glyphicon glyphicon-home"></span>&emsp;Découvrez Lens</p>
						</a>
					</div>
					<div class="sous_menu">
						<ul class="nav navbar-nav navbar-left">

						<?php
									echo '	<li class="nav-item"><a href="index.php?view=accueil">La carte</a></li>
											<li class="nav-item"><a href="index.php?view=projet">Le projet</a></li>
											<li class="nav-item"><a href="index.php?view=lieux">Les visites</a></li>
											<li class="nav-item"><a href="index.php?view=jeu">Jouez !</a></li>';
						?>

					</ul>
					
					<ul class="nav navbar-nav navbar-right">

						<?php 	if (!valider("connecte","SESSION"))
								{
									echo '	<li class="nav-item"><a href="index.php?view=signIn">S\'inscrire</a></li>
											<li class="nav-item"><a href="index.php?view=logIn">Se connecter</a></li>	';
								}
						
								if (valider("connecte","SESSION"))
								{
									$score = score();
									echo '	
											<li class="dropdown active">
												<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>&emsp;
													'. $_SESSION['pseudo'] .'&emsp; <span class="caret"></span>
												</a>
												<ul class="dropdown-menu">
													<ul class="nav nav-pills nav-stacked">
														<li><a href="#">Score : '. $score.'</a></li>
													</ul>
												</ul>
											</li>
											<li class="nav-item"><a href="controleur.php?action=Logout">Se déconnecter</a></li>'
											;
								}
						?>
						<li class="nav-item"><img src="./ressources/france.png" alt="france" width="40" height="40"/><img src="./ressources/england.png" alt="england" width="40" height="40"/></li>
					</ul>
					</div>
				</div>
			</nav>

