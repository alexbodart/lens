<?php

	if (basename($_SERVER["PHP_SELF"]) != "index.php")
	{
		header("Location:../index.php?view=accueil");
		die("");
	}

?>

	<body id="acc">
			<!-- Begin Click2Map Widget -->
			<script type="text/javascript">
			_c2m_user = "alexbodart";
			_c2m_map = "Lens";
			_c2m_widget_width = "500";
			_c2m_widget_height = "500";
			document.write('<iframe id="c2m_map_widget" src="https://www.click2map.com/v2/'+_c2m_user+'/'+_c2m_map+'/widget" width="'+_c2m_widget_width+'" height="'+_c2m_widget_height+'" frameborder="0"></iframe>');
			</script>
			<!-- End Click2Map Widget -->
			
	</body>