<?php

$q = $_REQUEST["q"];

switch ($q) {
    case 1:
        $hint ="Inauguré en 1927, cet édifice dont la forme évoque celle d’une locomotive, est emblématique de l’Art déco à Lens tant sur le plan technique que stylistique. L’architecte Urbain Cassan a dû tenir compte du risuqe important d’affaissements de terrain liés à l’extraction minière. Il a ainsi proposé un bâtiment marqué par l’horizontalité, composé de modules simples d’un seul niveau t qui s’étend sur plus de 80m. Il a par ailleurs utilisé le béton armé, nouveau matériau, léger et facile à mettre en œuvre. L’architecture des bâtiments annexes (ancien buffet, bâtiment des « roulants »…) adopte les mêmes caractéristiques que celles du bâtiment principal. La façade de la gare affiche une grande sobriété, le décor se résumant à une simple frise de losanges située sous la corniche. Ce motif trouve un écho sur les grilles, œuvre du ferronnier d’art Edgar Brandt, qui s’est largement distingué lors de l’Exposition Internationale de 1925 en signant le Pavillon de l’ambassade française. A L’intérieur, les mosaïques d’inspiration cubiste réalisées par Auguste Labouret représentant notamment la mine, témoignent encore du soin apporté à la décoration.";
        break;
    case 2:
        $hint ="Au n°29 se trouve un exemple typique de maison Art déco, tant par ses volumes que par les ornements de façade : présence de bow-window continu sur deux niveaux, motifs de roses stylisées en bas-relief repris aux différents étages, garde-corps en ferronnerie aux formes géométriques. L’immeuble du n°66, qui date des années 1950, présente une façade inspirée du style régionaliste avec son pignon à pas-de-moineaux et ses jeux de briques en saillie. ";
        break;
    case 3:
        $hint ="La demeure bourgeoise à l’angle avec la rue Michelet étonne par son architecture électrique, caractéristique des grandes villas urbaines du début du XXe siècle. Les larges débords de toiture soutenus par des corbeaux en bois peints évoquent l’architecture balnéaire tandis que les mosaïques aux tons bleu et o soulignent l’influence de l’Art éco. La tourelle d’angle rappelle quant à elle les échauguettes de château- fort médiéval. ";
        break;
    case 4:
        $hint ="Dominée par l’église Saint-Léger, la place Jean-Jaurès cœur historique de la ville, est agrandie lors de la Reconstruction. Les immeubles qui la bordent adoptent des styles architecturaux variés. S’y côtoient des façades régionalistes (n°14), des façades plus classiques (n°11) ornées de guirlandes sculptées de fleurs et de fruits et des façades typiquement Art déco (n°3 et n°4). Certains commerçants font de leur façade une véritable « vitrine » comme au n°18 « A la ville de Limoges » où les murs sont habillés de mosaïques figurant les objets mis en vente. D’autres choisissent d’imiter l’architecture des grands magasins qui privilégie la lumière à la faveur de grandes baies vitrées. L’édifice situé à l’intersection des rues Berthelot et Sizeranne illustre parfaitement ce parti pris, conforté par la présence d’une rotonde d’angle. ";
        break;
    case 5:
        $hint ="L’ancienne église datait de 1780. Détruite pendant la Première Guerre Mondiale, elle est reconstruite à l’identique par l’architecte douaisien Jean Goniaux et inaugurée en 1926. Le recours au béton armé plutôt qu’à la pierre permet d’alléger la structure de l’édifice et de limiter les éventuels affaissements de terrain. Ainsi, les contreforts qui existaient en façade sont supprimés au pofit d’un portail d’entrée plus monumental. ";
        break;
    case 6:
        $hint ="Situé derrière l’église Saint-Léger, le nouveau bureau de poste est inauguré en 1926. Réalisé par Bruno Pellissier, architecte actif à Paris et en Normandie, l’édifice s’inscrit dans le mouvement Art déco : deux façades aux lignes épurées se déploient de part et d’autre d’une entrée ménagée en arrondi sur l’angle. L’ensemble est rythmé de larges baies.";
        break;
    case 7:
        $hint ="L’iconographie de ce monument ne glorifie pas les vainqueurs, elle met en exergue les ravages provoqués par la guerre et souligne le traumatisme subi par la ville et ses habitants. De part et d’autre d’une galerie de mine au boisage brisé, le sculpteur Augustin Lesieux a représenté un mineur en habit de travail, les poings serrés et un soldat, le regard tourné vers l’horizon. A l’arrière, une mère et sa fille fuient la guerre. Dominant l’ensemble, une femme indignée, figurant la Ville de Lens, foule du pied de la guerre représentée par une torpille. Inauguré en 1925, ce monument occupe la place de Cantin jusqu’en 1972, date à laquelle il est transféré sur le rond-point de l’Avenue Alfred Van Pelt. ";
        break;
    case 8:
        $hint ="Au n°7 se trouve l’ancien bureau de bienfaisance. Mis en service en 1927 sous la houlette de la municipalité, il rassemble diverses fonctions (consultation des nourrissons, dépistages de la tuberculose…). Un des frontons de la façade est orné du blason de la ville représentant l’ancien château comtal flanqué de la Croix de Guerre et de la Croix de la Légion d’honneur, décernées à Lens après la Première Guerre mondiale. Au-dessus, sont évoqués les attributs du mineur : le pinc, la lampe et la barrette (casque en cuir bouilli du mineur). L’ensemble est entouré d’entrelacs et de motifs floraux stylisés. Plus loin aux n°31 et 33, les maisons se distinguent par un jeu de volumétries de toitures et par le travail extrêmement fouillé des décors floraux situés dans les parties hautes. 
";
        break;
    case 9:
        $hint ="Edifiée en réaction à la catastrophe de Courrières de 1906, la Maison Syndicale est un édifice emblématique des luttes ouvrières des mineurs. Inaugurée en 1911, elle est détruite pendant le Première Guerre mondiale et reconstruite quasiment à l’identique en 1926. Inspirée des modèles classiques – maçonnerie en brique et bossage de pierre, travée centrale en légère saillie surmontée d’un fronton semi-circulaire, balustrade, yeux de bœuf en toiture – l’architecture souligne la volonté d’afficher la puissance du syndicat vis –à-vis du patronat. ";
        break;
    case 10:
        $hint ="Prolongeant la Place Jean Jaurès, ce boulevard commerçant est l’une des principales artères du centre-ville et se caractérise surtout par son éclectisme architectural. Cet immeuble allure haussmannienne, avec son balcon continu, permet de mettre en valeur l’angle de la rue. ";
        break;
    case 11:
        $hint ="Prolongeant la Place Jean Jaurès, ce boulevard commerçant est l’une des principales artères du centre-ville et se caractérise surtout par son éclectisme architectural. Occupe les anciens locaux de l’école Condorcet. Construit au début des années 1920, le bâtiment est orné de mosaïques décoratives reprenant les symboles de la Ville : les initiales V et L pour Ville de Lens ainsi que l’ancien château comtal, motif également utilisé pour le blason de la commune. ";
        break;
    case 12:
        $hint ="Prolongeant la Place Jean Jaurès, ce boulevard commerçant est l’une des principales artères du centre-ville et se caractérise surtout par son éclectisme architectural. Ce vaste bâtiment annonce l’architecture moderne tout en s’inspirant du régionalisme à travers 3 pignons aux lignes verticales en brique qui rythment la façade. ";
        break;
    case 13:
        $hint ="Prolongeant la Place Jean Jaurès, ce boulevard commerçant est l’une des principales artères du centre-ville et se caractérise surtout par son éclectisme architectural. Cette petite maison de ville se remarque par son bow-window en arrondi et par son motif décoratif, caractéristique de l’Art déco : une corbeille de fleurs stylisées en bas-relief sur le pignon reprise sur le garde-corps en ferronnerie. ";
        break;
    case 14:
        $hint ="Prolongeant la Place Jean Jaurès, ce boulevard commerçant est l’une des principales artères du centre-ville et se caractérise surtout par son éclectisme architectural. Il s’agit là d’un bel exemple de façade Art déco. Le bow-window, continu sur deux niveaux, est porté par des consoles à gradins. De nombreux motifs floraux en bas-relief ornent la façade. Sous la corniche, des étançons en bois sculptés imitant les gargouilles du Moyen-âge apportent une petite originalité. ";
        break;
    case 15:
        $hint ="Construit par Louis-Marie Cordonnier de 1928 à 1930, cet édifice abritait à l’origine les Grands bureaux de la puissante Société des Mines de Lens. L’architecte a conçu un bâtiment de style régionaliste tout en intégrant de manière habile des éléments issus du vocabulaire Art déco : traitement en continu des linteaux des fenêtres, consoles en gradins supportant le balcon central, bow-windows latéraux, motifs décoratifs géométriques obtenus par des jeux de briques en saillie et par l’alternance des couleurs. Ce véritable « château de l’industrie » est magnifié par la présence d’un jardin à la française élaboré par le paysagiste Achille Duchêne. A l’intérieur l’Art déco s’affirme largement. Des luminaires de la maison Daum aux boiseries et au mobilier estampillés Majorelle, en passant par les ferronneries ou encore les cheminées en marbre, l’ensemble témoigne d’un grand raffinement. ";
        break;
    case 16:
        $hint ="Aux abords immédiats des anciens Grands bureaux, ces maisons édifiées pendant l’entre-deux guerres se distinguent par leurs dimensions imposantes et leurs qualités architecturales (variété de matériaux mis en œuvre, volumétries, décors). Elles témoignent du rang élevé de leurs occupants dans la hiérarchie de la Société. Les décors géométriques, composés à partir de briques disposées en retrait et en saillie, ne sont pas sans rappeler ceux visibles sur les façades des Grands bureaux. ";
        break;
    case 17:
        $hint ="Aux abords immédiats des anciens Grands bureaux, ces maisons édifiées pendant l’entre-deux guerres se distinguent par leurs dimensions imposantes et leurs qualités architecturales (variété de matériaux mis en œuvre, volumétries, décors). Elles témoignent du rang élevé de leurs occupants dans la hiérarchie de la Société. Avec leurs volumétries de toiture complexes et leurs colombages (bleus pour l’une, marrons pour l’autre), ces deux maisons rappellent les villas balnéaires anglo-normandes. Les colombages sont un des éléments de décor caractéristiques du style architectural développé par la société des Mines de Lens pour ses logements miniers. Il s’agit, pour la plupart des maisons de mineurs, de faux colombages en briques peintes. La présence des garages atteste, s’il en était besoin, de l’aisance des cadres de la Société. ";
        break;
    case 18:
        $hint ="Aux abords immédiats des anciens Grands bureaux, ces maisons édifiées pendant l’entre-deux guerres se distinguent par leurs dimensions imposantes et leurs qualités architecturales (variété de matériaux mis en œuvre, volumétries, décors). Elles témoignent du rang élevé de leurs occupants dans la hiérarchie de la Société. Cette maison et le mur de clôture de son vaste jardin se caractérisent par le recours à la pierre meulière à joints rubanés. Souvent associé aux belles demeures de banlieue parisienne ou aux villas balnéaires, ce matériau a été utilisé par la Société des Mines de Lens pour donner du cachet aux habitations de ses ingénieurs mais également à certains équipements (écoles, ateliers de couture etc.) et même à certains bâtiments de ses carreaux de fosses. ";
        break;
    case 19:
        $hint ="Aux abords immédiats des anciens Grands bureaux, ces maisons édifiées pendant l’entre-deux guerres se distinguent par leurs dimensions imposantes et leurs qualités architecturales (variété de matériaux mis en œuvre, volumétries, décors). Elles témoignent du rang élevé de leurs occupants dans la hiérarchie de la Société. Cette maison correspond au modèle type de maisons d’ingénieur édifiées à proximité des fosses. Ses dimensions, les larges débords de toitures et les décors de motifs géométriques composés à partir de briques de couleurs différentes la distinguent des maisons réservées aux simples mineurs. Au premier niveau, une porte-fenêtre ouvre sur un petit balcon surmontant le porche. Ce dispositif se retrouve également sur les presbytères des cités de la très paternaliste Société des Mines de Lens. L’ingénieur et le prêtre pouvait ainsi s’adresser à la population minière en différentes occasions. ";
        break;
    case 20:
        $hint ="Construit par les mineurs de la fosse 5 de la Société des Mines de Lens lors de la crise économique de 1929, le stade Félix Bollaert – André Delelis est un temple du football réputé pour la ferveur de son public. Inauguré en 1933, il est remanié plusieurs fois avant de prendre sa configuration de stade « à l’anglaise ». Le stade fait actuellement l’objet de travaux de rénovation afin d’être notamment en mesure d’accueillir des matchs lors de l’Euro 2016. ";
        break;
    case 21:
        $hint ="Inauguré le 4 décembre 2012, le musée du Louvre-Lens est édifié sur un ancien site d’extraction du charbon. Au cœur d’un vaste parc, il offre un voyage inédit dans les collections du célèbre musée parisien. Ce grand musée symbolise le renouveau du territoire. Conçus par les architectes japonais de l’agence SANAA, la bâtiments s’inscrivent de manière harmonieuse et subtile dans leur environnement au travers d’un dialogue permanent avec l’écrin paysagé de l’ancienne friche minière. Contrairement au musée parisien, structuré autour de départements (peintures, antiquités égyptiennes, arts de l’Islam etc.), la présentation des œuvres se fait ici au sein d’un même espace décloisonné : la Galerie du Temps. Le Louvre-Lens propose donc un regard différent et innovant sur les collections du Louvre. ";
        break;    
    default:
        $hint="";
        break;
}


// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "" : $hint;
?>