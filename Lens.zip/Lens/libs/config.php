<?php

$BDD_host="localhost";
$BDD_user="root";
$BDD_password=""; // vide sous windows
$BDD_base="lens";

?>
