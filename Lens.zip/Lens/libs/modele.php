<?php


/*CREATE VIEW vuetrajet AS SELECT u.id as idUser, t.idTrajet, p.estConducteur, u.nom, u.prenom, t.date, t.heure, t.typeTrajet, t.sensTrajet, t.nbPlaces, t.nbPlacesActuelles FROM users as u, trajet as t, participant as p WHERE u.id = p.idUsager AND t.idTrajet = p.idTrajet;*/

// inclure ici la librairie faciliant les requêtes SQL
include_once("maLibSQL.pdo.php");

function console_log( $data, $context = 'Debug in Console' ) {

    // Buffering to solve problems frameworks, like header() in this and not a solid return.
    ob_start();

    $output  = 'console.info( \'' . $context . ':\' );';
    $output .= 'console.log(' . json_encode( $data ) . ');';
    $output  = sprintf( '<script>%s</script>', $output );

    echo $output;
}

function listerUtilisateurs($classe = "both")
{
	// NB : la présence du symbole '=' indique la valeur par défaut du paramètre s'il n'est pas fourni
	// Cette fonction liste les utilisateurs de la base de données 
	// et renvoie un tableau d'enregistrements. 
	// Chaque enregistrement est un tableau associatif contenant les champs 
	// id,pseudo,blacklist,connecte,couleur

	// Lorsque la variable $classe vaut "both", elle renvoie tous les utilisateurs
	// Lorsqu'elle vaut "bl", elle ne renvoie que les utilisateurs blacklistés
	// Lorsqu'elle vaut "nbl", elle ne renvoie que les utilisateurs non blacklistés

	$SQL = "select * from users";
	if ($classe == "bl")
		$SQL .= " where blacklist=1";
	if ($classe == "nbl")
		$SQL .= " where blacklist=0";
	
	// echo $SQL;
	return parcoursRs(SQLSelect($SQL));

}
function verifUserBdd($login,$passe)
{
	// Vérifie l'identité d'un utilisateur 
	// dont les identifiants sont passes en paramètre
	// renvoie faux si user inconnu
	// renvoie l'id de l'utilisateur si succès
	
	//$passe=md5($passe);
	$SQL="SELECT id FROM users WHERE pseudo='$login' AND passe='$passe'";

	return SQLGetChamp($SQL);
	// si on avait besoin de plus d'un champ
	// on aurait du utiliser SQLSelect
}

function checkUser($pseudo)
{
	$SQL="SELECT count(*) FROM users WHERE pseudo='$pseudo'";
	return SQLGetChamp($SQL);
}

function AjouterScore($joueur,$question,$reponseok)
{
		
		$SQL = "INSERT INTO `reponse` (`idusers`,`idquestion`,`reponse_ok`) VALUES ('$joueur','$question','$reponseok')";
		SQLInsert($SQL);
}

function AjouterUtilisateur($nom,$prenom,$login,$passe)
{	
		$SQL = "INSERT INTO `users` (`nom`,`prenom`,`pseudo`, `passe`) VALUES ('$nom','$prenom','$login','$passe')";
		SQLInsert($SQL); 
}

function recupTrajets()
{	
		$SQL = "SELECT * FROM listes ORDER BY dates";
		return parcoursRs(SQLSelect($SQL)); 
}

function verifPassager($id_trajet,$id_passager)
{
		$SQL = "SELECT * FROM participants WHERE passager_id='$id_passager' and trajet_id='$id_trajet'";
		return parcoursRs(SQLSelect($SQL));
}

function score()
{		
		$score=0;
		$id_user = $_SESSION['id'];
		try {
			$dbh = new PDO("mysql:host=localhost;dbname=lens", 'root','');
		} catch (PDOException $e) {
			die("<font color=\"red\">SQLUpdate/Delete: Erreur de connexion : " . $e->getMessage() . "</font>");
		}
		$reponse = $dbh->query("SELECT reponse_ok FROM reponse WHERE idusers='$id_user' and reponse_ok=1");
		while ($donnees = $reponse->fetch())
		{
			$score++;
		}
		return $score;
}

?>
